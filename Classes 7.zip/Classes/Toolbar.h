//
//  Toolbar.h
//  Eden
//
//  Created by Ari Ronen on 9/10/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface Toolbar : NSObject {
    
}
- (BOOL)update:(float)etime;
- (void)render;

@end



