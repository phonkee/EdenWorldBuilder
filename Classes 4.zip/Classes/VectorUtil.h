//
//  VectorUtil.h
//  Eden
//
//  Created by Ari Ronen on 3/17/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#ifndef Eden_VectorUtil_h
#define Eden_VectorUtil_h

#include "Vector.h"

Vector rotateVertice(Vector rot,Vector v);

#endif
