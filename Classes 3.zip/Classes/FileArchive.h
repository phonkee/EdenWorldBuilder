//
//  FileArchive.h
//  Eden
//
//  Created by Ari Ronen on 5/10/14.
//
//

#ifndef Eden_FileArchive_h
#define Eden_FileArchive_h

void CompressWorld(const char* world);
NSString* getArchiveName(NSString* name);
BOOL DecompressWorld(const char* world);
BOOL addToIndex(const char* fname,NSString* desc_name);
BOOL readIndex();
#endif
