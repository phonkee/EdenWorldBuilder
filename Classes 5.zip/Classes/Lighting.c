//
//  Lighting.c
//  Eden
//
//  Created by Ari Ronen on 1/21/13.
//
//

#include <stdio.h>
