//
//  Geometry.h
//  Eden
//
//  Created by Ari Ronen on 4/25/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#ifndef Eden_Geometry_h
#define Eden_Geometry_h


#import <OpenGLES/ES1/gl.h>
#import <OpenGLES/ES1/glext.h>
#define INDICES_MAX 32768

void tc_initGeometry();

#endif
